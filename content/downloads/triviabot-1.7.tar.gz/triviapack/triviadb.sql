CREATE TABLE `categorie` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(100) default NULL,
  `descrizione` text,
  `attiva` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
CREATE TABLE `domande` (
  `id` int(11) NOT NULL auto_increment,
  `id_categoria` smallint(6) default NULL,
  `livello` smallint(6) default NULL,
  `domanda` varchar(250) default NULL,
  `risposta` varchar(100) default NULL,
  `punti` smallint(6) default '0',
  `aiuti` text,
  PRIMARY KEY  (`id`),
  KEY `idx_dom_cat_liv` (`id_categoria`,`livello`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
CREATE TABLE `giocatori` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nome` varchar(45) NOT NULL default '',
  `punti` decimal(12,2) NOT NULL default '0.00',
  `oldpunti` decimal(12,2) NOT NULL default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `giochidefault` (
  `id` int(11) NOT NULL auto_increment,
  `id_categoria` int(11) default NULL,
  `canale` varchar(40) default NULL,
  `livello` smallint(6) default '1',
  `domande` smallint(6) default '20',
  `tempomax` int(11) default '20',
  `password` varchar(30) NOT NULL default '',
  `showrisposta` smallint(5) unsigned NOT NULL default '1',
  `color` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
CREATE TABLE `gradi` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(60) default NULL,
  `maxpunti` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
CREATE TABLE `partite` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `canale` varchar(45) NOT NULL default '',
  `categoria` varchar(255) NOT NULL default '0',
  `livello` int(10) unsigned NOT NULL default '0',
  `ndomande` int(10) unsigned NOT NULL default '0',
  `tempomax` int(10) unsigned NOT NULL default '0',
  `showrisposta` int(10) unsigned NOT NULL default '0',
  `data` date NOT NULL default '0000-00-00',
  `gid` int(10) unsigned NOT NULL default '0',
  `dfatte` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `validchan` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nome` varchar(45) NOT NULL default '',
  `nick` varchar(45) default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
