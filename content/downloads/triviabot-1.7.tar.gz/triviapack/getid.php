<?php
/*
Azzurra TriviaBot (c) 2006 Azzurra IRC Network
Original code by gigi-x (gigi-x@azzurra.org)

This program is free but copyrighted software; see the file COPYING for
details.
*/


$dbhost='';
$dbname='';
$dbpass='';

/* Connessione e selezione del database */
$connessione = mysql_connect("$dbhost", "$dbname", "$dbpass")
or die("Connessione non riuscita: " . mysql_error());
mysql_select_db("trivia") or die("Selezione del database non riuscita");
                   
/* Esecuzione di una query SQL */
$query = "SELECT max(id) from partite";
$rcount = mysql_query($query) or die("Query fallita: " . mysql_error() );
$num = mysql_result($rcount, 0, 0);  
print "$num";
/* Chiusura della connessione */
mysql_close($connessione);
?> 